# papers
Here are subtopics you can use to split work evenly among all authors under the same main paper.

## High-level subtopics

- Problem Statement and Motivation  
- Background on Cloud Incidents and RCA  
- Limitations of Traditional RCA Approaches  
- System Requirements and Design Goals  

## Architecture and Data

- Overall System Architecture  
- Service Topology and Dependency Modeling  
- Data Sources: Logs, Metrics, Traces  
- Data Preprocessing and Normalization  

## AI/ML and Causal Inference

- Log Embeddings and Feature Extraction  
- Anomaly Detection and Clustering  
- Causal Graph Construction and Assumptions  
- Root-Cause Inference Algorithm  

## Implementation and Experiments

- Prototype Implementation in Cloud/Microservices  
- Dataset Description and Experiment Setup  
- Evaluation Metrics (e.g., MTTR, Accuracy)  
- Experimental Results and Case Studies  

## Security and DevSecOps

- Security Incident Scenarios and Threat Models  
- Integration with Monitoring and SIEM Tools  
- DevSecOps Workflow and Automation  
- Reliability, Scalability, and Performance Analysis  

## Discussion and Wrap‑up

- Interpretability and Trust in AI RCA  
- Limitations and Threats to Validity  
- Future Work and Extensions  
- Conclusion

## work assignment 

* Arun Kumar Rajamandrapu – Introduction & Use Cases
    * Define the problem statement, motivation, and limitations of existing RCA approaches.
    * Write cloud incident scenarios, reliability challenges, and vehicle/real-world examples.
* Ravikanth Reddy Gudipati – Security & Incident Management
    * Specify security-related incident types, threat models, and log/telemetry sources.
    * Describe how the RCA system supports SOC workflows and incident response playbooks.
* Vinod Kumar Gujja – AI/ML & Data Pipeline
    * Design the data flow: log embeddings, anomaly clustering, metric aggregation.
    * Write the sections on model selection, training, evaluation metrics, and feature engineering.
* Dr. Quazi Taif Sadat – Causal Modeling & Methodology
    * Formalize the causal graphs, assumptions, and inference strategy.
    * Write the methodology subsections and help structure any mathematical formulation.
* Harish Apuri – Implementation & Experiments
    * Implement the prototype in a microservice/cloud environment.
    * Run experiments, collect results, and write the implementation and evaluation sections.
* Senthilnathan Balasubramaniam – Architecture & DevSecOps Integration
    * Design system architecture diagrams and deployment/topology descriptions.
    * Write about CI/CD, observability integration, and how the RCA fits into DevSecOps.

## Topic timelines
Align each subtopic with a clear start/end window and one primary lead (you can map to authors as needed):
* Problem Statement, Motivation, Background
    * Start: 01 July 2025
    * First draft: 15 August 2025
    * Final revisions: 01 November 2025
* System Requirements and Design Goals
    * Start: 20 July 2025
    * First draft: 30 August 2025
    * Final revisions: 05 November 2025
* System Architecture & Service Topology
    * Start: 01 August 2025
    * Architecture draft: 15 September 2025
    * Diagrams finalized: 15 November 2025
* Data Sources & Preprocessing (Logs, Metrics, Traces)
    * Start: 10 August 2025
    * Pipeline draft: 25 September 2025
    * Final cleaning/description: 20 November 2025
* Log Embeddings, Anomaly Detection & Clustering
    * Start: 20 August 2025
    * Experiments complete: 10 October 2025
    * Method/results text finalized: 25 November 2025
* Causal Graphs & Root-Cause Inference Algorithm
    * Start: 01 September 2025
    * Theory and design fixed: 20 October 2025
    * Text and equations finalized: 25 November 2025
* Cloud Implementation & Microservices Prototype
    * Start: 15 August 2025
    * First working prototype: 15 October 2025
    * Final implementation details written: 30 November 2025
* Experiments, Metrics, and Case Studies
    * Start: 01 October 2025
    * Main experiments complete: 15 November 2025
    * Figures/tables and narrative finalized: 05 December 2025
* Security, SIEM Integration & DevSecOps Workflow
    * Start: 05 September 2025
    * Integration concepts and diagrams: 25 October 2025
    * Final write-up: 30 November 2025
* Discussion, Limitations, Future Work, Conclusion
    * Start: 10 November 2025
    * Draft: 30 November 2025
    * Final pass (all authors): 10 December 2025